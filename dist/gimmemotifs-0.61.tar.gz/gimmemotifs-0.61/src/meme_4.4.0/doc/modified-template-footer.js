/* 
 * $Id: template-footer.js 2539 2008-04-04 18:22:39Z cegrant $
 * 
 * $Log$
 * Revision 1.2  2006/03/07 23:30:20  nadya
 * merge branches v3_5_1 and v3_5_2 back to the trunk
 *
 * Revision 1.1.2.1  2006/02/22 20:47:48  nadya
 * initial revision. enabling styling with js and css
 *
 */
document.write('\
  <table style="text-align: center;" width="100%"> \
    <tr> \
      <td style="text-align: left;"><b>Version 4.4.0</b></td> \
      <td style="text-align: center;"> \
        <b>Please send comments and questions to: \
        <a href="mailto:@bla">@bla</a></b> \
      </td> \
      <td style="text-align: right;"> \
        <b>Powered by <a href="http://nbcr.net/services/opal/">Opal</a></b> \
      </td> \
    </tr> \
   </table> \
   <hr/> \
   <table align="center"> \
     <tr style="text-align: center;"> \
       <td><a href="http://meme.nbcr.net">Home</a></td> \
       <td><a href="authors.html">Authors</a></td> \
       <td><a href="cite.html">Citing</a></td> \
      </tr> \
    </table> \
');
