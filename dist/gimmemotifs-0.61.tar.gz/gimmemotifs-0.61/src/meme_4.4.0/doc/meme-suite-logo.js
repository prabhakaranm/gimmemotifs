/* Write out the Meme Suite logo */
document.write(
  '<table style=\"padding: 0; font-family: sans-serif; font-weight: bold; margin-bottom: 22px;\">' 
  + '<tr>'
  + '<td style=\"padding-left: 0; padding-right: 0; padding-top: 0; padding-bottom: 0;'
  + '           margin-top: 0; margin-bottom: 0; font-size: 36px; color: #008F8F; \" '
  + '>'
  + 'The MEME Suite'
  + '</td>'
  + '</tr>'
  + '<tr style=\"border-bottom-color: #008F8F; border-bottom-style: double;\">'
  + '<td style=\"padding-left: 0; padding-right: 0; padding-top: 0; margin-top: 0; font-size: 22px;\">' 
  + 'Motif-based sequence analysis tools'
  + '</td>' 
  + '</tr>'
  + '</table>'
);
