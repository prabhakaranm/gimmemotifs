#!/bin/sh

# cd trawler/
perl bin/trawler.pl -dir_id expl1 -sample examples/REB1_YPD.fsa -background examples/background_yeast_Young_6k.fsa

exit 0
